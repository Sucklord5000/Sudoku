﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class Connect
    {
        private int port;
        private IPEndPoint EndPoint;
        private System.Net.Sockets.Socket socket;
        private GeneratedField field;
        private int[,] Field;
        private List<Client> User;
        private int CountUser;
        private List<string> NameUser;
        private int NextStep = 1;
        private byte[] ByteArray;
        public Connect()
        {
            this.User = new List<Client>();
            this.port = 8005;
            this.NameUser = new List<string>();
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            this.CountUser = 1;
            this.EndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), port);
            this.socket = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            this.socket.Bind(this.EndPoint);
            this.socket.Listen(10);

            this.Field = new int[9, 9];
            this.field = new GeneratedField();
            Field = field.GetReadyField();
            ByteArray = ConvertToByte();
            new Thread(OnConnectedUser).Start();
        }
        private void OnConnectedUser()
        {
            while (true)
            {
                Socket handler = socket.Accept();
                try
                {
                    this.User.Add(new Client()
                    {
                        Socket = handler,
                        ID = this.CountUser++,
                    });
                    CheckName(this.User[this.User.Count - 1]);
                }
                catch (Exception e)
                {
                   
                }                         
            }
        }
        private byte[] ConvertToByte()
        {
            byte[] mas = new byte[324];
            for (int a = 0, Count = 0; a < 9; a++)
                for (int b = 0; b < 9; b++, Count++)
                    mas[Count] = Convert.ToByte(this.Field[a, b]);
            return mas;
        }
        private void CheckName(Client client)
        {
            Boolean flag = true;
            while (flag)
            {
                try
                {
                    byte[] data = new byte[client.Socket.ReceiveBufferSize];
                    do
                    {
                        client.Socket.Receive(data);
                        var formatter = new BinaryFormatter();
                        var stream = new MemoryStream(data);
                        var obj = (ClassLibrary2.Class1)formatter.Deserialize(stream);
                        Console.WriteLine(obj.Commands);
                        switch (obj.Commands)
                        {
                            case ClassLibrary2.Class1.Command.AddNameUser:
                                {
                                    if (!this.NameUser.Contains(obj.Name))
                                    {
                                        client.Name = obj.Name;
                                        this.NameUser.Add(obj.Name);
                                        obj.Commands = ClassLibrary2.Class1.Command.NameFree;
                                        flag = false;
                                        stream = new MemoryStream();
                                        formatter.Serialize(stream, obj);
                                        client.Socket.Send(stream.ToArray());
                                    }
                                    else
                                    {
                                        obj.Commands = ClassLibrary2.Class1.Command.NameOccupied;

                                        stream = new MemoryStream();
                                        formatter.Serialize(stream, obj);
                                        client.Socket.Send(stream.ToArray());
                                    }

                                }
                                break;
                        }
                        if (flag == false)
                            break;
                    } while (client.Socket.Available > 0);
                }
                catch
                {
                    flag = false;
                }
            }
            ThreadPool.QueueUserWorkItem(x => ClickNumberToField(this.User[this.User.Count - 1]));
        }
        private void ClickNumberToField(Client client)
        {
            while (true)
            {
                try
                { 
                    byte[] data = new byte[client.Socket.ReceiveBufferSize];
                    do
                    {
                        client.Socket.Receive(data);
                        var formatter = new BinaryFormatter();
                        var stream = new MemoryStream(data);
                        var obj = (ClassLibrary2.Class1)formatter.Deserialize(stream);
                        Console.WriteLine(obj.Commands);
                        switch (obj.Commands)
                        {
                            case ClassLibrary2.Class1.Command.SendField:
                                {
                                    stream = new MemoryStream();
                                    obj.Field = ByteArray;
                                    formatter.Serialize(stream, obj);
                                    client.Socket.Send(stream.ToArray());
                                    stream.Dispose();
                                }
                                break;
                            case ClassLibrary2.Class1.Command.AllDone:
                                {
                                    NextStepUser();
                                }
                                break;
                            case ClassLibrary2.Class1.Command.SetPositionOnField:
                                {
                                    if (this.NextStep < this.User.Count)
                                        this.NextStep++;
                                    else
                                        this.NextStep = 1;

                                    int[] mas = new int[4];
                                    Field[mas[1], mas[2]] = mas[3];


                                    for (int a = 0; a < this.User.Count; a++)
                                    {
                                        if (this.User.Count == 1)
                                        {
                                            using (stream = new MemoryStream())
                                            {
                                                obj.Play = true;
                                                formatter.Serialize(stream, obj);
                                                client.Socket.Send(stream.ToArray());
                                            }
                                        }
                                        else
                                        {
                                            if (this.User[a].ID == this.NextStep)
                                            {
                                                using (stream = new MemoryStream())
                                                {
                                                    obj.Play = true;
                                                    formatter.Serialize(stream, obj);
                                                    this.User[a].Socket.Send(stream.ToArray());
                                                }
                                            }
                                            else
                                            {
                                                using (stream = new MemoryStream())
                                                {
                                                    obj.Play = false;
                                                    formatter.Serialize(stream, obj);
                                                    this.User[a].Socket.Send(stream.ToArray());
                                                }
                                            }
                                        }
                                    }
                                }

                                break;
                            case ClassLibrary2.Class1.Command.ShowPlayersOnline:
                                {
                                    using (stream = new MemoryStream())
                                    {
                                        for (int a = 0; a < this.NameUser.Count; a++)
                                            obj.Add(this.NameUser[a]);
                                        formatter.Serialize(stream, obj);
                                        client.Socket.Send(stream.ToArray());
                                    }
                                }
                                break;
                        }
                    } while (client.Socket.Available > 0);
                }
                catch (Exception e)
                {
                    var formatter = new BinaryFormatter();
                    using (var stream = new MemoryStream())
                    {
                        var obj = new ClassLibrary2.Class1();
                        obj.Commands = ClassLibrary2.Class1.Command.DisconnectUser;
                        obj.Name = client.Name;
                        obj.Play = false;

                        if (!String.IsNullOrEmpty(client.Name))
                        {
                            this.NameUser.Remove(this.NameUser.Find(x => x.Contains(client.Name)));
                            for (int a = 0; a < this.NameUser.Count; a++)
                                obj.Add(this.NameUser[a]);

                            this.User.Remove(client);
                            if (this.User.Count == 1)
                            {
                                obj.Play = true;
                                formatter.Serialize(stream, obj);
                                for (int a = 0; a < this.User.Count; a++)
                                    this.User[a].Socket.Send(stream.ToArray());
                                this.CountUser = 1;
                                this.NextStep = 1;
                            }
                            else if (this.User.Count == 0)
                                this.NameUser.Clear();
                            else
                            {
                                obj.Play = false;
                                formatter.Serialize(stream, obj);
                                for (int a = 0; a < this.User.Count; a++)
                                    this.User[a].Socket.Send(stream.ToArray());

                                this.CountUser--;

                                if (this.NextStep < this.User.Count)
                                    this.NextStep++;
                                else
                                    this.NextStep = 1;

                                NextStepUser();

                            }
                        }
                    }
                    break;
                }
            }
        }
        private void NextStepUser()
        {
            BinaryFormatter formatter = new BinaryFormatter();
            var obj = new ClassLibrary2.Class1();
            for (int a = 0,ID = 1; a < this.User.Count; a++,ID++)
            {
                this.User[a].ID = ID;
                if (this.User[a].ID == this.NextStep)
                {
                    using (var stream = new MemoryStream())
                    {
                        obj.Play = true;
                        obj.Commands = ClassLibrary2.Class1.Command.AllDone;
                        formatter.Serialize(stream, obj);
                        this.User[a].Socket.Send(stream.ToArray());
                    }
                }
                else
                {
                    using (var stream = new MemoryStream())
                    {
                        obj.Play = false;
                        obj.Commands = ClassLibrary2.Class1.Command.AllDone;
                        formatter.Serialize(stream, obj);
                        this.User[a].Socket.Send(stream.ToArray());
                    }
                }
            }
        }
    }
}