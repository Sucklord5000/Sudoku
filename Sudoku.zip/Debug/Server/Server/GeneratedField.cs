﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class GeneratedField
    {
        private int[,] button;
        private Random random;
        public GeneratedField()
        {
            this.button = new int[9, 9];
            this.random = new Random();
            GetReadyField();
        }
        public int[,] GetReadyField()
        {
            GeneratedRow();
            Transposing();
            SwapRowSmall(0, 3);
            SwapColumnSmall(0, 3);
            RandomHideButton();
            return this.button;
        }
        private void RandomHideButton()
        {
            int Count = random.Next(10, 20);
            for (int a = 0; a < Count; a++)
                this.button[random.Next(0, 9), random.Next(0, 9)] = 0;
        }
        private void Transposing()
        {
            int[,] mas = new int[button.GetLength(0), button.GetLength(1)];
            Array.Copy(button, mas, button.Length);
            for (int a = 0; a < 9; a++)
                for (int i = 0; i < 9; i++)
                    button[i, a] = mas[a, i];
        }
        private void SwapRowSmall(int From, int To)
        {
            int[] mas = new int[9];

            int[] mas2 = new int[9];

            int RandRow = random.Next(0, 3);
            int RandRowFromSwap = 0;
            do
            {
                RandRowFromSwap = random.Next(0, 3);
            } while (RandRowFromSwap == RandRow);


            for (int i = 0; i < 9; i++)
                mas[i] = button[RandRow, i];

            for (int b = 0; b < 9; b++)
                mas2[b] = button[RandRowFromSwap, b];

            for (int i = 0; i < 9; i++)
            {
                button[RandRow, i] = mas2[i];
                button[RandRowFromSwap, i] = mas[i];
            }
            if (To < 9)
                SwapRowSmall(To, To + 3);
        }
        private void GeneratedRow()
        {
            int Counter = 1;
            for (int a = 0; a < 9; a++)
            {
                for (int i = 0; i < 9; i++)
                {
                    if (Counter == 10)
                        Counter = 1;
                    else if (button[a, i] == 9 && i == 7)
                        Counter = 1;

                    button[a, i] = Counter;
                    Counter++;
                }

                if (a == 2 || a == 5 || a == 8)
                    Counter = button[a, 4];
                else
                    Counter = button[a, 3];
            }
        }
        private void SwapColumnSmall(int From, int To)
        {
            int[] mas = new int[9];

            int[] mas2 = new int[9];

            int RandColumn = random.Next(0, 3);
            int RandColumnFromSwap = 0;
            do
            {
                RandColumnFromSwap = random.Next(0, 3);
            } while (RandColumnFromSwap == RandColumn);


            for (int i = 0; i < 9; i++)
                mas[i] = button[i, RandColumn];

            for (int b = 0; b < 9; b++)
                mas2[b] = button[b, RandColumnFromSwap];

            for (int i = 0; i < 9; i++)
            {
                button[i, RandColumn] = mas2[i];
                button[i, RandColumnFromSwap] = mas[i];
            }
            if (To < 9)
                SwapColumnSmall(To, To + 3);
        }
    }
}
